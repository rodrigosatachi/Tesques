/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Rodrigo
 */
public class tela extends javax.swing.JFrame {

    /**
     * Creates new form tela
     */
    public tela() {
        // Isso inícia a thread
        // new Time().start();
        initComponents();
    }
    
    public class armazenar{
        
        private String path;
        
        private boolean append_to_file = false;
        
        public armazenar(String file_path) {
            
            path = file_path;
            
        }
        
        public armazenar( String file_path , boolean append_value ) {

            path = file_path;
            
            append_to_file = append_value;
            
        }
        
        public void writeToFile( String textLine ) throws IOException {
                
            FileWriter write = new FileWriter( path , append_to_file);
            
            PrintWriter print_line = new PrintWriter( write );
            
            print_line.printf( "%s" + "%n" , textLine);
            
            print_line.close();
        }
    }


    
    // Código para desenhar com o mouse
    /*
    ArrayList<Desenho> desenhos = new ArrayList<>();
    
    public class Desenho{
        
        int x, y;
        public Desenho (int x, int y)
        {
            this.x = x;
            this.y = y;
        }}
    
    public void paint(Graphics g){
        for(int i=1; i<desenhos.size();i++){
            int x = desenhos.get(i).x;
            int y = desenhos.get(i).y;
            int x2 = desenhos.get(i-1).x;
            int y2 = desenhos.get(i-1).y;
            g.drawLine(x2, y2, x, y);
        }
    }
    
    public class Time extends Thread{
        public void run(){
            while(true) {
                try {
                Point ponto = getMousePosition();
                desenhos.add(new Desenho(ponto.x,ponto.y));
                }catch(Exception erro){}
                repaint();
            }
        }
    }*/
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panel1 = new javax.swing.JPanel();
        texto1 = new javax.swing.JScrollPane();
        text1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        save = new javax.swing.JButton();
        ler1 = new javax.swing.JButton();
        jCheckBox5 = new javax.swing.JCheckBox();
        panel2 = new javax.swing.JPanel();
        texto2 = new javax.swing.JScrollPane();
        text2 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        save1 = new javax.swing.JButton();
        ler2 = new javax.swing.JButton();
        jCheckBox4 = new javax.swing.JCheckBox();
        panel3 = new javax.swing.JPanel();
        texto3 = new javax.swing.JScrollPane();
        text3 = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        save2 = new javax.swing.JButton();
        ler3 = new javax.swing.JButton();
        jCheckBox3 = new javax.swing.JCheckBox();
        kai = new javax.swing.JButton();
        thai = new javax.swing.JButton();
        dark = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1200, 800));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        panel1.setBackground(new java.awt.Color(204, 204, 204));
        panel1.setPreferredSize(new java.awt.Dimension(250, 400));
        panel1.setRequestFocusEnabled(false);
        panel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                panel1MouseDragged(evt);
            }
        });
        panel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panel1MousePressed(evt);
            }
        });

        text1.setColumns(20);
        text1.setRows(5);
        text1.setAutoscrolls(false);
        text1.setBorder(null);
        text1.setMinimumSize(new java.awt.Dimension(0, 0));
        text1.setName(""); // NOI18N
        texto1.setViewportView(text1);

        jButton1.setText("fechar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        save.setText("Salvar");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        ler1.setText("Abrir");
        ler1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ler1ActionPerformed(evt);
            }
        });

        jCheckBox5.setText("Done");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox5)
                    .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                            .addComponent(save)
                            .addGap(18, 18, 18)
                            .addComponent(ler1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGap(18, 18, 18)
                            .addComponent(jButton1))
                        .addComponent(texto1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(texto1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(save)
                    .addComponent(ler1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel2.setBackground(new java.awt.Color(204, 204, 204));
        panel2.setPreferredSize(new java.awt.Dimension(250, 400));
        panel2.setRequestFocusEnabled(false);
        panel2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                panel2MouseDragged(evt);
            }
        });
        panel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel2MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panel2MousePressed(evt);
            }
        });

        text2.setColumns(20);
        text2.setRows(5);
        text2.setAutoscrolls(false);
        text2.setBorder(null);
        text2.setMinimumSize(new java.awt.Dimension(0, 0));
        text2.setName(""); // NOI18N
        texto2.setViewportView(text2);

        jButton2.setText("fechar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        save1.setText("Salvar");
        save1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save1ActionPerformed(evt);
            }
        });

        ler2.setText("Abrir");
        ler2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ler2ActionPerformed(evt);
            }
        });

        jCheckBox4.setText("Done");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox4)
                    .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                            .addComponent(save1)
                            .addGap(18, 18, 18)
                            .addComponent(ler2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGap(18, 18, 18)
                            .addComponent(jButton2))
                        .addComponent(texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox4)
                .addGap(5, 5, 5)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(save1)
                    .addComponent(ler2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel3.setBackground(new java.awt.Color(204, 204, 204));
        panel3.setPreferredSize(new java.awt.Dimension(250, 400));
        panel3.setRequestFocusEnabled(false);
        panel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                panel3MouseDragged(evt);
            }
        });
        panel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel3MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panel3MousePressed(evt);
            }
        });

        text3.setColumns(20);
        text3.setRows(5);
        text3.setAutoscrolls(false);
        text3.setBorder(null);
        text3.setMinimumSize(new java.awt.Dimension(0, 0));
        text3.setName(""); // NOI18N
        texto3.setViewportView(text3);

        jButton4.setText("fechar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        save2.setText("Salvar");
        save2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save2ActionPerformed(evt);
            }
        });

        ler3.setText("Abrir");
        ler3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ler3ActionPerformed(evt);
            }
        });

        jCheckBox3.setText("Done");

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox3)
                    .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(texto3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(panel3Layout.createSequentialGroup()
                            .addComponent(save2)
                            .addGap(18, 18, 18)
                            .addComponent(ler3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGap(18, 18, 18)
                            .addComponent(jButton4))))
                .addContainerGap())
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(texto3, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(save2)
                    .addComponent(ler3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        kai.setText("Kai");
        kai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kaiActionPerformed(evt);
            }
        });

        thai.setText("Thai-Wan");
        thai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thaiActionPerformed(evt);
            }
        });

        dark.setText("Dark");
        dark.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                darkActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(131, 131, 131)
                        .addComponent(kai, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(dark, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(1003, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(thai)
                    .addContainerGap(1118, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 960, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kai)
                    .addComponent(dark))
                .addGap(21, 21, 21))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(507, Short.MAX_VALUE)
                    .addComponent(thai)
                    .addGap(21, 21, 21)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        private int xMouse, yMouse;
    private void panel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel1MousePressed
        xMouse=evt.getX();
        yMouse=evt.getY();
        
    }//GEN-LAST:event_panel1MousePressed

    private void panel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel1MouseDragged
        int x=evt.getXOnScreen();
        int y=evt.getYOnScreen();
        this.panel1.setLocation(x-xMouse, y-yMouse);
    }//GEN-LAST:event_panel1MouseDragged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        panel1.setSize(10, 10);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void panel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel1MouseClicked
        float xp,yp;
        xp = panel1.getWidth();
        yp = panel1.getHeight();
        if(xp <= 10 && yp <= 10){
            panel1.setSize(245, 390);
        }// TODO add your handling code here:
    }//GEN-LAST:event_panel1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        panel2.setSize(10, 10);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void panel2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel2MouseDragged
        int x=evt.getXOnScreen();
        int y=evt.getYOnScreen();
        this.panel2.setLocation(x-xMouse, y-yMouse);
    }//GEN-LAST:event_panel2MouseDragged

    private void panel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel2MouseClicked
        float xp,yp;
        xp = panel2.getWidth();
        yp = panel2.getHeight();
        if(xp <= 10 && yp <= 10){
            panel2.setSize(245, 390);
        }
    }//GEN-LAST:event_panel2MouseClicked

    private void panel2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel2MousePressed
        xMouse=evt.getX();
        yMouse=evt.getY();
    }//GEN-LAST:event_panel2MousePressed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        panel3.setSize(10, 10);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void panel3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel3MouseDragged
        int x=evt.getXOnScreen();
        int y=evt.getYOnScreen();
        this.panel3.setLocation(x-xMouse, y-yMouse);
    }//GEN-LAST:event_panel3MouseDragged

    private void panel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel3MouseClicked
         float xp,yp;
        xp = panel3.getWidth();
        yp = panel3.getHeight();
        if(xp <= 10 && yp <= 10){
            panel3.setSize(245, 390);
        }
    }//GEN-LAST:event_panel3MouseClicked

    private void panel3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel3MousePressed
        xMouse=evt.getX();
        yMouse=evt.getY();
    }//GEN-LAST:event_panel3MousePressed

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1MousePressed

    private void kaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kaiActionPerformed
        jPanel1.setBackground(new Color(94,30,169));
        panel1.setBackground(new Color(255,189,47));
        panel2.setBackground(new Color(255,189,47));
        panel3.setBackground(new Color(255,189,47));
        kai.setBackground(new Color(255,189,47));
        thai.setBackground(new Color(255,189,47));
        dark.setBackground(new Color(255,189,47));
        // TODO add your handling code here:
    }//GEN-LAST:event_kaiActionPerformed

    private void thaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thaiActionPerformed
        jPanel1.setBackground(new Color(65,193,186));
        panel1.setBackground(new Color(54,91,109));
        panel2.setBackground(new Color(54,91,109));
        panel3.setBackground(new Color(54,91,109));
        kai.setBackground(new Color(54,91,109));
        thai.setBackground(new Color(54,91,109));
        dark.setBackground(new Color(54,91,109));
    }//GEN-LAST:event_thaiActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        
        JFileChooser fc = new JFileChooser();
        
        fc.showSaveDialog(this);
        
        File f=fc.getSelectedFile();
        
        try{
            FileWriter fw = new FileWriter(f);
            String text = text1.getText();
            fw.write(text);
            fw.close();
            
        }
        catch(IOException e){
            
            System.out.println(e);
            
        }
        
    }//GEN-LAST:event_saveActionPerformed

    private void save1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save1ActionPerformed
        JFileChooser fc = new JFileChooser();
        
        fc.showSaveDialog(this);
        
        File f=fc.getSelectedFile();
        
        try{
            FileWriter fw = new FileWriter(f);
            String text = text2.getText();
            fw.write(text);
            fw.close();
            
        }
        catch(IOException e){
            
            System.out.println(e);
            
        }
    }//GEN-LAST:event_save1ActionPerformed

    private void save2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save2ActionPerformed
        JFileChooser fc = new JFileChooser();
        
        fc.showSaveDialog(this);
        
        File f=fc.getSelectedFile();
        
        try{
            FileWriter fw = new FileWriter(f);
            String text = text3.getText();
            fw.write(text);
            fw.close();
            
        }
        catch(IOException e){
            
            System.out.println(e);
            
        }
    }//GEN-LAST:event_save2ActionPerformed

    private void darkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_darkActionPerformed
        jPanel1.setBackground(new Color(51,51,51));
        panel1.setBackground(new Color(240,240,240));
        panel2.setBackground(new Color(240,240,240));
        panel3.setBackground(new Color(240,240,240));
        kai.setBackground(new Color(240,240,240));
        thai.setBackground(new Color(240,240,240));
        dark.setBackground(new Color(240,240,240));
    }//GEN-LAST:event_darkActionPerformed

    private void ler3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ler3ActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        
        try{
            FileReader reader = new FileReader(filename);
            BufferedReader br = new BufferedReader(reader);
            text3.read(br, null);
            br.close();
            text3.requestFocus();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_ler3ActionPerformed

    private void ler2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ler2ActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        
        try{
            FileReader reader = new FileReader(filename);
            BufferedReader br = new BufferedReader(reader);
            text2.read(br, null);
            br.close();
            text2.requestFocus();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_ler2ActionPerformed

    private void ler1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ler1ActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        
        try{
            FileReader reader = new FileReader(filename);
            BufferedReader br = new BufferedReader(reader);
            text1.read(br, null);
            br.close();
            text1.requestFocus();
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_ler1ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tela().setVisible(true);
            }
        });
         
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dark;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton kai;
    private javax.swing.JButton ler1;
    private javax.swing.JButton ler2;
    private javax.swing.JButton ler3;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel3;
    private javax.swing.JButton save;
    private javax.swing.JButton save1;
    private javax.swing.JButton save2;
    private javax.swing.JTextArea text1;
    private javax.swing.JTextArea text2;
    private javax.swing.JTextArea text3;
    private javax.swing.JScrollPane texto1;
    private javax.swing.JScrollPane texto2;
    private javax.swing.JScrollPane texto3;
    private javax.swing.JButton thai;
    // End of variables declaration//GEN-END:variables
}
